char F2C_version[] = "20200916";
char xxxvers[] = "\n@(#) FORTRAN 77 to C Translator, VERSION 20200916\n";
